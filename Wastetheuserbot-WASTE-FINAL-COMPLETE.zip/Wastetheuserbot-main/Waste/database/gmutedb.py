# © By Waste shukla (Github = itzshukla) You are motherfucker if you Don't gives credits.

from Waste.database import cli

gmuteh = cli["GMUTE"]


async def is_gmuted(sender_id):
    kk = await gmuteh.find_one({"sender_id": sender_id})
    return bool(kk)


async def gmute(sender_id, reason="#GMuted"):
    await gmuteh.insert_one({"sender_id": sender_id, "reason": reason})


async def ungmute(sender_id):
    await gmuteh.delete_one({"sender_id": sender_id})
