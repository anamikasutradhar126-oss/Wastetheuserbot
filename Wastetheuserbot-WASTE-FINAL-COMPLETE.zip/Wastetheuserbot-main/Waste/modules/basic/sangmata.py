# © By Waste shukla (Github = itzshukla) You are motherfucker if you Don't gives credits.

import asyncio
from pyrogram import *
from pyrogram import filters
from pyrogram.errors import YouBlockedUser
from pyrogram.types import *
from Waste.modules.help import add_command_help
from Waste.modules.basic.profile import extract_user


@Client.on_message(filters.command(["sg", "sa", "sangmata"], [".", "/"]) & filters.me)
async def sg(client: Client, message: Message):
    args = await extract_user(message)
    lol = await message.edit_text("`ᴘʀᴏᴄᴇssɪɴɢ...`")
    if args:
        try:
            user = await client.get_users(args)
        except Exception:
            return await lol.edit(f"`ᴘʟᴇᴀsᴇ sᴘᴇᴄɪғʏ ᴀ ᴠᴀʟɪᴅ ᴜsᴇʀ!`")
    bot = "SangMata_BOT"
    try:
        await client.send_message(bot, f"/allhistory {user.id}")
    except YouBlockedUser:
        await client.unblock_user(bot)
        await client.send_message(bot, f"/allhistory {user.id}")
    await asyncio.sleep(1)

    async for stalk in client.search_messages(bot, query="Name", limit=1):
        if not stalk:
            await message.edit_text("**ᴏʀᴀɴɢ ɪɴɪ ʙᴇʟᴜᴍ ᴘᴇʀɴᴀʜ ᴍᴇɴɢɢᴀɴᴛɪ ɴᴀᴍᴀɴʏᴀ**")
            return
        elif stalk:
            await message.edit(stalk.text)
            await stalk.delete()

    async for stalk in client.search_messages(bot, query="Username", limit=1):
        if not stalk:
            return
        elif stalk:
            await message.reply(stalk.text)
            await stalk.delete()


add_command_help(
    "sangmata",
    [
        [
            "sg [reply/userid/username]",
            "Its help uh to find someone name history.",
        ],
    ],
)
